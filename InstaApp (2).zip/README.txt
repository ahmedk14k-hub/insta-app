Build the APK (no Android Studio needed):
1. Create a free GitHub account and a new repository.
2. Upload ALL files of this folder (including the hidden .github folder).
3. Open the Actions tab -> "Build APK" -> wait ~3 min.
4. Download "InstaApp-apk" (contains app-debug.apk) and send it to your friends.

Or open this folder in Android Studio -> Build -> Build APK(s).
Change the link: START_URL in MainActivity.java.
