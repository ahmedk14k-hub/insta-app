package com.ap9ap.insta;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

public class MainActivity extends Activity {

    private static final String START_URL = "https://www.ap9ap.com/insta";
    private static final long MIN_SPLASH_MS = 1600;

    private WebView webView;
    private ProgressBar progress;
    private View splash;
    private boolean failed = false;
    private boolean splashDone = false;
    private long startTime;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startTime = System.currentTimeMillis();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#14275F"));

        // ---- WebView ----
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#14275F"));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- thin top progress bar ----
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        // ---- splash screen ----
        splash = buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false; // stay inside the app
                }
                try { // tel:, mailto:, whatsapp:, tg: ...
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                failed = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplash();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failed = true;
                    view.loadDataWithBaseURL(null, errorHtml(), "text/html", "UTF-8", null);
                    hideSplash();
                }
            }
        });

        // safety: never keep the splash forever
        handler.postDelayed(this::hideSplash, 10000);

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }
    }

    private View buildSplash() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#0C1032"), Color.parseColor("#1D3E77"), Color.parseColor("#142852")});
        box.setBackground(bg);
        box.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, getResources().getDisplayMetrics().widthPixels);
        box.addView(logo, lpLogo);

        ProgressBar spinner = new ProgressBar(this);
        LinearLayout.LayoutParams lpS = new LinearLayout.LayoutParams(dp(30), dp(30));
        lpS.topMargin = dp(4);
        box.addView(spinner, lpS);

        // entrance animation
        logo.setScaleX(0.6f); logo.setScaleY(0.6f); logo.setAlpha(0f);
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(700)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        return box;
    }

    private void hideSplash() {
        if (splashDone) return;
        long wait = MIN_SPLASH_MS - (System.currentTimeMillis() - startTime);
        handler.postDelayed(() -> {
            if (splashDone) return;
            splashDone = true;
            splash.animate().alpha(0f).setDuration(450)
                    .withEndAction(() -> splash.setVisibility(View.GONE)).start();
        }, Math.max(0, wait));
    }

    private String errorHtml() {
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='margin:0;display:flex;align-items:center;justify-content:center;"
                + "height:100vh;background:linear-gradient(135deg,#6A3FB5,#14275F,#1B3F8F);color:#fff;"
                + "font-family:sans-serif;text-align:center;direction:rtl'>"
                + "<div style='padding:24px'><div style='font-size:64px'>📡</div>"
                + "<h2>لا يوجد اتصال بالإنترنت</h2>"
                + "<p style='opacity:.8'>تأكد من الاتصال ثم حاول مرة ثانية</p>"
                + "<button onclick=\"location.href='" + START_URL + "'\" "
                + "style='font-size:18px;padding:12px 34px;border:0;border-radius:30px;"
                + "background:#fff;color:#14275F;font-weight:bold'>إعادة المحاولة</button>"
                + "</div></body></html>";
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack() && !failed) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
